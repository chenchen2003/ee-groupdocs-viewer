<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Groupdocs_viewer_ft Class
 *
 * @package			ExpressionEngine
 * @category		Fieldtype
 * @author			GroupDocs Teem
 * @copyright		
 * @link			http://groupdocs.com/
 */
 
class Groupdocs_viewer_ft extends EE_Fieldtype {
	
	var $info = array(
		'name'		=> 'Embedded Groupdocs Viewer',
		'version'	=> '0.0.1'
	);
	
	var $prefix = 'groupdocs_viewer_';
	
	// --------------------------------------------------------------------
	
	/**
	 * Display Field on Publish
	 * This handles both displaying default values from Channel Fields > Edit Field OR Global Settings
	 * And reading saved data from channel entry. $data contains entry saved data with existing entry 
	 *
	 * @access	public
	 * @param	existing data
	 * @return	field html
	 *
	 */
	function display_field($data)
	{
		$data_points = array('client_id', 'api_key');
		
		if ($data)
		{
			list($client_id, $api_key) = explode('|', $data);
		}
		else
		{
			foreach($data_points as $key)
			{
				$$key = $this->settings[$key];
			}
		}
		
		// override values from POST if present
		if(!empty($_POST)) {
			
			foreach($data_points as $key) {
				
				if(!empty($_POST[$this->prefix.$key])) {
					$$key = $this->EE->input->post($this->prefix.$key,TRUE);
				}
			}
		}

		$options = compact($data_points);
		
		$form = '';
		$form .= '<div style="float:left;width:50%;">';
			
		$form .= form_label('Embed code', $this->prefix.'embed_code');
		$form .= form_input($this->prefix.'embed_code', $client_id, ' class="embed_code" style="border-color:white;"');
			
		$form .= '<br /><span class="'.$this->prefix.'feedback" style="display:block;margin-top:5px;color:steelBlue;"></span>';
		$form .= '</div>';

		return $form;
	}
	
	// --------------------------------------------------------------------
	
	/**
	 * Prep data for saving
	 *
	 * @access	public
	 * @param	posted data
	 * @return	string
	 *
	 */
	function save($data)
	{
	
		$data = $this->EE->input->post($this->prefix.'embed_code', TRUE);
		
		return $data;
	}
	
	
	// --------------------------------------------------------------------
	
	function validate($data) {
		
		return TRUE;
		
	}
	 
	// --------------------------------------------------------------------
		
	/**
	 * Replace tag
	 *
	 * @access	public
	 * @param	field contents
	 * @return	replacement text
	 *
	 */
	function replace_tag($data, $params = array(), $tagdata = FALSE)
	{
		$iframe = "<iframe src='https://apps.groupdocs.com/document-viewer/embed/$data' frameborder='0' width='600' height='700'></iframe>";

		return $iframe;
	}
	// --------------------------------------------------------------------
		
	/**
	 * Replace tag modifiers
	 *
	 * @access	public
	 * @param	1 vairable from field contents
	 * @return	replacement text
	 *
	 */
	function replace_client_id($data, $params = array(), $tagdata = FALSE)
	{

		list($client_id, $api_key) = explode('|', $data);
		
		return $client_id;
	}
	
	function replace_api_key($data, $params = array(), $tagdata = FALSE)
	{

		list($client_id, $api_key) = explode('|', $data);
		
		return $api_key;
	}
	
	// --------------------------------------------------------------------
	
	/**
	 * Display Global Settings
	 * View Addons > Fieldtypes > Google Maps Lat Lng Lookup 
	 *
	 * @access	public
	 * @return	form contents
	 *
	 */
	function display_global_settings()
	{
		$val = array_merge($this->settings, $_POST);
		
		
		$form = '';
		
		$form .= '<h3>Default Details</h3>';
		
		$form .= '<p>';
		$form .= form_label('Client ID', 'client_id').form_input('client_id', $val['client_id']);
		$form .= form_label('API Key', 'api_key').form_input('api_key', $val['api_key']);
		$form .= '</p>';
		$form .= '<p>';
		$form .= '<br /><span class="feedback"></span>';
		$form .= '</p>';

		return $form;
	}

	// --------------------------------------------------------------------
	
	/**
	 * Save Global Settings
	 *
	 * @access	public
	 * @return	global settings
	 *
	 */
	function save_global_settings()
	{
		return array_merge($this->settings, $_POST);
	}
	
	// --------------------------------------------------------------------

	/**
	 * Save Settings
	 *
	 * @access	public
	 * @return	field settings
	 *
	 */
	function save_settings($data)
	{
		return array(
			'client_id'	=> $this->EE->input->post('client_id'),
			'api_key'	=> $this->EE->input->post('api_key')
		);
	}
	
	// --------------------------------------------------------------------
	
	/**
	 * Install Fieldtype
	 *
	 * @access	public
	 * @return	default global settings
	 *
	 */
	function install()
	{
		return array(
			'client_id'	=> '',
			'api_key'	=> ''
		);
	}
	
	// --------------------------------------------------------------------
	
}

/* End of file ft.groupdocs_viewer.php */
